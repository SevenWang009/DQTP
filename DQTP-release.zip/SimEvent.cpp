#include "StdAfx.h"
#include "SimEvent.h"


CSimEvent::CSimEvent(void)
{
}


CSimEvent::~CSimEvent(void)
{
}
